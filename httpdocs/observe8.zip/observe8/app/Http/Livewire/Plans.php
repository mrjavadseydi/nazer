<?php

namespace App\Http\Livewire;

use App\Models\Plan;
use App\Models\Supervisor;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Mediconesystems\LivewireDatatables\Action;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Morilog\Jalali\Jalalian;

class Plans extends LivewireDatatable
{
    private $counter = 1;
    public $exportable = true;
    public $observesCount = 0;

    public function builder()
    {
        $user = Auth::user();
        if( Str::lower($user->role->name) == 'supervisor' ){
            $plans = Supervisor::where('nationalityCode', $user->nationalityCode)->first()->plans()->getQuery();
        }
        else{
            $plans = Plan::query();
        }

        return $plans
            ->join('performers', function ($join){
                $join->on('plans.performer_id', '=', 'performers.id');
            })
            ->leftJoin('supervisors', function ($join){
                $join->on('plans.supervisor_id', '=', 'supervisors.id');
            })
            ->leftJoin('observes', function ($join){
                $join->on('plans.id', '=', 'observes.plan_id');
            })
            ->leftJoin('organizations', function ($join){
                $join->on('plans.organization_id', '=', 'organizations.id');
            })
            ->groupBy('plans.id');
    }

    public function columns()
    {
        if( Str::lower(Auth::user()->role->name) == 'supervisor' ){
            return [
                NumberColumn::callback('id', function ($id){
                    return $this->counter++;
                })->label('ردیف')->alignRight()->headerAlignCenter(),
                Column::name('organizations.title')->label("اداره")->alignRight()->headerAlignCenter(),
                Column::name('performers.firstName')->label("نام")->alignRight()->headerAlignCenter(),
                Column::name('performers.lastName')->label("نام خانوادگی")->alignRight()->headerAlignCenter(),
                Column::name('performers.phone')->label("تلفن مجری")->alignRight()->headerAlignCenter()->editable(),
                Column::name('plans.title')->label("عنوان طرح")->alignRight()->headerAlignCenter(),
                Column::name('plans.category')->label("دسته بندی طرح")->alignRight()->headerAlignCenter(),
                Column::callback('performer.gender', function ($gender){
                    return $gender == 'male' ? 'مرد' : 'زن';
                })->label("جنسیت")->alignRight()->headerAlignCenter(),
                Column::name('plans.address')->label("آدرس")->alignRight()->headerAlignCenter()->editable(),
                Column::callback('plans.last_observe_date', function ($lastObserveDate){
                    if( $lastObserveDate == '' )
                        return null;
                    return miladi2shamsi('Y/m/d', $lastObserveDate);
                })->label("تاریخ آخرین بازدید")->alignRight()->headerAlignCenter(),
                Column::raw('COUNT(*)')->label('نظارت های انجام شده')->alignRight()->headerAlignCenter(),
                Column::callback(['id'], function ($id){
                    return view('livewire.plans-datatable', compact('id'));
                })->label('عملیات')->alignRight()->headerAlignCenter()
            ];
        }
        else{
            return [
                NumberColumn::callback('id', function ($id){
                    return $this->counter++;
                })->label('ردیف')->alignRight()->headerAlignCenter(),
                Column::name('organizations.title')->label("اداره")->alignRight()->headerAlignCenter(),
                Column::name('performers.firstName')->label("نام")->alignRight()->headerAlignCenter(),
                Column::name('performers.lastName')->label("نام خانوادگی")->alignRight()->headerAlignCenter(),
                Column::name('performers.phone')->label("تلفن مجری")->alignRight()->headerAlignCenter()->editable(),
                Column::name('plans.title')->label("عنوان طرح")->alignRight()->headerAlignCenter(),
                Column::name('plans.category')->label("دسته بندی طرح")->alignRight()->headerAlignCenter(),
                Column::callback('performer.gender', function ($gender){
                    return $gender == 'male' ? 'مرد' : 'زن';
                })->label("جنسیت")->alignRight()->headerAlignCenter(),
                Column::name('plans.address')->label("آدرس")->alignRight()->headerAlignCenter()->editable(),
                Column::name('supervisor.fullName')->label("نام ناظر")->alignRight()->headerAlignCenter(),
                Column::name('supervisor.phone')->label("تلفن ناظر")->alignRight()->headerAlignCenter()->editable(),
                Column::callback('plans.last_observe_date', function ($lastObserveDate){
                    if( $lastObserveDate == '' )
                        return null;
                    return miladi2shamsi('Y/m/d', $lastObserveDate);
                })->label("تاریخ آخرین بازدید")->alignRight()->headerAlignCenter(),
                Column::raw('COUNT(*)')->label('نظارت های انجام شده')->alignRight()->headerAlignCenter(),
                Column::callback(['id'], function ($id){
                    return view('livewire.plans-datatable', compact('id'));
                })->label('عملیات')->alignRight()->headerAlignCenter()
            ];
        }
    }

    public function filters()
    {

    }
}
