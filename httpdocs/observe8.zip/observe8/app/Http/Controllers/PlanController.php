<?php

namespace App\Http\Controllers;

use App\Models\Document;
use App\Models\Image;
use App\Models\Observe;
use App\Models\Organization;
use App\Models\Performer;
use App\Models\Plan;
use App\Models\Supervisor;
use Illuminate\Http\Request;

class PlanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     */
    public function index()
    {
        return view('pages.plans.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     */
    public function create()
    {
        $organizations = Organization::all();
        return view('pages.plans.add', compact('organizations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function store(Request $request)
    {
        $performerInfo = $request->performer;
        $planInfo = $request->plan;

        $performer = new Performer();
        $performer->firstName = $performerInfo['firstName'];
        $performer->lastName = $performerInfo['lastName'];
        $performer->nationalityCode = $performerInfo['nationalityCode'];
        $performer->birthday = $performerInfo['birthday'];
        $performer->phone = $performerInfo['phone'];
        $performer->gender = $performerInfo['gender'];
        $performer->under_support = $performerInfo['support'] == 'on';
        $performer->save();

        $plan = new Plan();
        $plan->title = $planInfo['title'];
        $plan->category = $planInfo['category'];
        $plan->tags = $planInfo['tags'];
        $plan->organization_id = $planInfo['organization'];
        $plan->distance = $planInfo['distance'];
        $plan->address = $planInfo['address'];
        $plan->implement_method = $planInfo['implement_method'];
        $plan->performer_id = $performer->id;
        $plan->supervisor_id = Supervisor::where('nationalityCode', $request->supervisor)->first()->id;
        $plan->save();

        return redirect()->route('plans.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function observes($planID)
    {
        $plan = Plan::find($planID);
        if( $plan == null )
            return redirect()->route('plans.index');

        $plan = $plan->load('organization');

        $observes = $plan->observes()->with(['performer', 'plan'])->get()->map( function ($observe){
            $observe->observe_date = miladi2shamsi('Y/m/d', $observe->observe_date);
            return $observe;
        } );

        $planDocuments = $plan->documents()->with('image')->get();
        $documents = Document::all()->diff($planDocuments);
        return view('pages.observes.add', compact('observes', 'plan', 'documents', 'planDocuments'));
    }

    public function storeObserve(Request $request, $planID)
    {
        $date = fa2en($request->observe_date);
        $expiration = shamsi2miladi('Y/m/d', $date);
        $date = $expiration->toDate();

        $plan = Plan::find($planID)->load(['supervisor', 'performer']);
        $plan->last_observe_date = $date;
        $plan->distance = $request->distance;
        $plan->latitude = $request->latitude;
        $plan->longitude = $request->longitude;
        $plan->save();

        $observe = new Observe();
        $observe->supervisor_id = $plan->supervisor->id;
        $observe->performer_id = $plan->performer->id;
        $observe->plan_id = $plan->id;
        $observe->observe_date = $date;
        $observe->save();

        foreach ($request->observe_files as $item) {
            $documentID = $item['document'];
            $document = $plan->documents()->find($documentID);

            if( !$document ){
                $image = new Image();
                $image->url = upload($item['compressed']);
                $image->document_id = $documentID;
                $image->plan_id = $plan->id;
                $image->save();

                $plan->documents()->attach($documentID);;
            }
        }
    }
}
