<?php return array (
  'documents' => 'App\\Http\\Livewire\\Documents',
  'organizations' => 'App\\Http\\Livewire\\Organizations',
  'plans' => 'App\\Http\\Livewire\\Plans',
  'supervisors' => 'App\\Http\\Livewire\\Supervisors',
);