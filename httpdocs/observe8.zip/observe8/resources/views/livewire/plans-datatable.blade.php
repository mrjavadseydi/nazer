<div>
    <a href="{{ route('observes.create', $id) }}" class="btn btn-sm btn-primary">
        ثبت نظارت
    </a>
</div>
