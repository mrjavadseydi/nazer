<div>
    <a href="{{ route('organizations.edit', $id) }}" class="btn btn-sm btn-warning">
        <i class="fas fa-edit"></i>
    </a>

    <a href="javascript:;" class="btn btn-sm btn-danger data-remove">
        <i class="fas fa-trash"></i>
    </a>
    <form action="{{ route('organizations.destroy', $id) }}" method="POST" class="d-none">
        @csrf
        @method('DELETE')
    </form>
</div>
