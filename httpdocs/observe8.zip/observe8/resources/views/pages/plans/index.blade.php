@extends('layout.master')
@section('dashboard_page_title', 'لیست طرح ها')

@section('dashboard_content')
    <div class="container-fluid">
        <livewire:plans/>
    </div>
@endsection
