@extends('layout.master')
@section('dashboard_page_title', 'افزودن ناظر جدید')

@section('dashboard_content')
    <div class="container-fluid text-right">
        <form action="{{ isset($supervisor) ? route('supervisors.update', $supervisor->id) : route('supervisors.store') }}" method="POST">
            @csrf
            @isset($supervisor)
                @method('PUT')
            @endisset
            <div class="card card-custom">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="" class="form-label">نام و نام خانوادگی</label>
                                <input type="text" class="form-control" name="fullName" @isset($supervisor) value="{{ $supervisor->fullName }}" @endisset>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="" class="form-label">تلفن همراه</label>
                                <input type="text" class="form-control" name="phone" @isset($supervisor) value="{{ $supervisor->phone }}" @endisset>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="" class="form-label">کد ملی</label>
                                <input type="text" class="form-control" name="nationalityCode" @isset($supervisor) value="{{ $supervisor->nationalityCode }}" @endisset>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="" class="form-label">آدرس</label>
                                <input type="text" class="form-control" name="address" @isset($supervisor) value="{{ $supervisor->address }}" @endisset>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary">@isset($supervisor) ویرایش اداره @else ثبت اداره @endif</button>
                </div>
            </div>
        </form>
    </div>
@endsection
