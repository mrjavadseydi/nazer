<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        $this->call([
            PermissionSeeder::class,
            RoleSeeder::class,
            UserSeeder::class,
            SupervisorSeeder::class,
            DocumentSeeder::class,
            OrganizationSeeder::class
        ]);
        Schema::enableForeignKeyConstraints();
        // \App\Models\User::factory(10)->create();
    }
}
