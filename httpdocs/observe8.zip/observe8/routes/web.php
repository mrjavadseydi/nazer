<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\OrganizationController;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\SupervisorController;
use App\Imports\ImportObserve;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('/')->middleware('guest')->group(function (){
    Route::get('/login', [AuthController::class, 'login'])->name('login');
    Route::post('/signIn', [AuthController::class, 'signIn'])->name('signIn');
    Route::post('/forgot', [AuthController::class, 'forgot'])->middleware('guest')->name('password.request');
    Route::get('/reset/{token}', [AuthController::class, 'resetForm'])->middleware('guest')->name('password.reset');
    Route::post('/reset', [AuthController::class, 'reset'])->middleware('guest')->name('reset.post');
});

Route::prefix('dashboard')->middleware('auth')->group(function (){
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('/plans', PlanController::class);
    Route::resource('/documents', DocumentController::class);
    Route::resource('/organizations', OrganizationController::class);
    Route::resource('/supervisors', SupervisorController::class);

    Route::get('/plan/{id}/observes', [PlanController::class, 'observes'])->name('observes.create');
    Route::post('/observes/{id}', [PlanController::class, 'storeObserve'])->name('observes.store');
});

Route::post('import', function (Request $request){
    $file = $request->file('file');
    Excel::import(new ImportObserve, $request->file('file'));
    return back();
})->name('import');

Route::post('/upload', function (Request $request){
    foreach ($request->file('image') as $image) {
        $name = Str::uuid();
        $image->move(public_path('uploads'));
    }
})->name('upload');
