<div>
    <a href="<?php echo e(route('documents.edit', $id)); ?>" class="btn btn-sm btn-warning">
        <i class="fas fa-edit"></i>
    </a>

    <a href="javascript:;" class="btn btn-sm btn-danger data-remove">
        <i class="fas fa-trash"></i>
    </a>
    <form action="<?php echo e(route('documents.destroy', $id)); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
</div>
<?php /**PATH /home/daniyal_s/projects/observe8/resources/views/livewire/documents-datatable.blade.php ENDPATH**/ ?>