<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted font-weight-bold mr-2">2022©</span>
            <a href="https://daneshjooyar.info" target="_blank" class="text-dark-75 text-hover-primary">ساخته شده با ❤️ توسط شرکت دانشجویار</a>
        </div>
        <!--end::Copyright-->
        <!--begin::Nav-->
        <div class="nav nav-dark">
            <?php
                $locale = \Illuminate\Support\Facades\Lang::getLocale();
            ?>
            <?php $__currentLoopData = \Illuminate\Support\Facades\Config::get('menu.footer'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($item['url']); ?>" target="_blank" class="nav-link <?php if($locale == 'fa'): ?> pl-5 pr-0 <?php else: ?> pl-0 pr-5 <?php endif; ?>"><?php echo e($item['title']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--end::Nav-->
    </div>
    <!--end::Container-->
</div>
<?php /**PATH /home/daniyal_s/projects/observe8/resources/views/components/footer.blade.php ENDPATH**/ ?>