<?php $__env->startSection('dashboard_page_title', 'ثبت بازدید'); ?>

<?php $__env->startPush('dashboard_extra_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/persian-datepicker.min.css')); ?>">
    <style>
        .datepicker-plot-area{
            border: unset!important;
            box-shadow: unset!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container-fluid">
        <div class="card card-custom gutter-b">
            <!--begin::Body-->
            <div class="card-body">
                <!--begin::Nav Tabs-->
                <ul class="dashboard-tabs nav nav-pills nav-primary row row-paddingless m-0 p-0 flex-column flex-sm-row" role="tablist">
                    <!--begin::Item-->
                    <li class="nav-item d-flex col-sm flex-grow-1 flex-shrink-0 mr-3 mb-3 mb-lg-0">
                        <a class="nav-link border py-10 d-flex flex-grow-1 rounded flex-column align-items-center active" data-toggle="pill" href="#tab_forms_widget_1">
                            <span class="nav-icon py-2 w-auto">
                                <span class="svg-icon svg-icon-3x">
                                    <!--begin::Svg Icon | path:/metronic/theme/html/demo1/dist/assets/media/svg/icons/Home/Library.svg-->
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <rect fill="#000000" x="4" y="11" width="16" height="2" rx="1"/>
                                            <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000) " x="4" y="11" width="16" height="2" rx="1"/>
                                        </g>
                                    </svg>
                                    <!--end::Svg Icon-->
                                </span>
                            </span>
                            <span class="nav-text font-size-lg py-2 font-weight-bold text-center">ثبت بازدید</span>
                        </a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="nav-item d-flex col-sm flex-grow-1 flex-shrink-0 mr-3 mb-3 mb-lg-0">
                        <a class="nav-link border py-10 d-flex flex-grow-1 rounded flex-column align-items-center" data-toggle="pill" href="#tab_forms_widget_2">
                        <span class="nav-icon py-2 w-auto">
                            <span class="svg-icon svg-icon-3x">
                                <!--begin::Svg Icon | path:/metronic/theme/html/demo1/dist/assets/media/svg/icons/Layout/Layout-4-blocks.svg-->
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <rect x="0" y="0" width="24" height="24"/>
                                        <path d="M5.5,2 L18.5,2 C19.3284271,2 20,2.67157288 20,3.5 L20,6.5 C20,7.32842712 19.3284271,8 18.5,8 L5.5,8 C4.67157288,8 4,7.32842712 4,6.5 L4,3.5 C4,2.67157288 4.67157288,2 5.5,2 Z M11,4 C10.4477153,4 10,4.44771525 10,5 C10,5.55228475 10.4477153,6 11,6 L13,6 C13.5522847,6 14,5.55228475 14,5 C14,4.44771525 13.5522847,4 13,4 L11,4 Z" fill="#000000" opacity="0.3"/>
                                        <path d="M5.5,9 L18.5,9 C19.3284271,9 20,9.67157288 20,10.5 L20,13.5 C20,14.3284271 19.3284271,15 18.5,15 L5.5,15 C4.67157288,15 4,14.3284271 4,13.5 L4,10.5 C4,9.67157288 4.67157288,9 5.5,9 Z M11,11 C10.4477153,11 10,11.4477153 10,12 C10,12.5522847 10.4477153,13 11,13 L13,13 C13.5522847,13 14,12.5522847 14,12 C14,11.4477153 13.5522847,11 13,11 L11,11 Z M5.5,16 L18.5,16 C19.3284271,16 20,16.6715729 20,17.5 L20,20.5 C20,21.3284271 19.3284271,22 18.5,22 L5.5,22 C4.67157288,22 4,21.3284271 4,20.5 L4,17.5 C4,16.6715729 4.67157288,16 5.5,16 Z M11,18 C10.4477153,18 10,18.4477153 10,19 C10,19.5522847 10.4477153,20 11,20 L13,20 C13.5522847,20 14,19.5522847 14,19 C14,18.4477153 13.5522847,18 13,18 L11,18 Z" fill="#000000"/>
                                    </g>
                                </svg>
                                <!--end::Svg Icon-->
                            </span>
                        </span>
                            <span class="nav-text font-size-lg py-2 font-weight-bolder text-center">همه بازدید های انجام شده</span>
                        </a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="nav-item d-flex col-sm flex-grow-1 flex-shrink-0 mr-3 mb-3 mb-lg-0">
                        <a class="nav-link border py-10 d-flex flex-grow-1 rounded flex-column align-items-center" data-toggle="pill" href="#tab_forms_widget_3">
                        <span class="nav-icon py-2 w-auto">
                            <span class="svg-icon svg-icon-3x">
                                <!--begin::Svg Icon | path:/metronic/theme/html/demo1/dist/assets/media/svg/icons/Layout/Layout-4-blocks.svg-->
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <rect x="0" y="0" width="24" height="24"/>
                                        <path d="M3.5,21 L20.5,21 C21.3284271,21 22,20.3284271 22,19.5 L22,8.5 C22,7.67157288 21.3284271,7 20.5,7 L10,7 L7.43933983,4.43933983 C7.15803526,4.15803526 6.77650439,4 6.37867966,4 L3.5,4 C2.67157288,4 2,4.67157288 2,5.5 L2,19.5 C2,20.3284271 2.67157288,21 3.5,21 Z" fill="#000000" opacity="0.3"/>
                                        <path d="M8.63657261,16.4632487 C7.65328954,15.8436137 7,14.7480988 7,13.5 C7,11.5670034 8.56700338,10 10.5,10 C12.263236,10 13.7219407,11.3038529 13.9645556,13 L15,13 C16.1045695,13 17,13.8954305 17,15 C17,16.1045695 16.1045695,17 15,17 L10,17 C9.47310652,17 8.99380073,16.7962529 8.63657261,16.4632487 Z" fill="#000000"/>
                                    </g>
                                </svg>
                                <!--end::Svg Icon-->
                            </span>
                        </span>
                            <span class="nav-text font-size-lg py-2 font-weight-bolder text-center">مدارک</span>
                        </a>
                    </li>
                    <!--end::Item-->
                </ul>
                <!--end::Nav Tabs-->
            </div>
            <!--end::Body-->
        </div>

        <div class="card card-custom">
            <div class="card-body">
                <!--begin::Nav Content-->
                <div class="tab-content m-0 mt-4 p-0">
                    <div class="tab-pane active" id="tab_forms_widget_1" role="tabpanel">
                        <form action="<?php echo e(route('observes.store', $plan->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row text-right">
                                <div class="col-lg-4 border-left border-left-light-dark">
                                    <label for="" class="form-label">تاریخ بازدید</label>
                                    <input type="text" class="form-control persianDate mb-8" name="observe_date">
                                    <div id="persianDateBox"></div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="row border-bottom border-bottom-light-dark">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="" class="form-label">موقعیت مکانی</label>
                                                <div class="row align-items-start">
                                                    <div class="form-group col-lg-4">
                                                        <input type="text" class="form-control" id="latitude" name="latitude" value="<?php echo e($plan->latitude); ?>">
                                                    </div>
                                                    <div class="form-group col-lg-4">
                                                        <input type="text" class="form-control" id="longitude" name="longitude" value="<?php echo e($plan->longitude); ?>">
                                                    </div>
                                                    <button class="btn btn-primary" type="button" onclick="getLocation()">دریافت لوکیشن فعلی</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="" class="form-label">فاصله اداره تا موقعیت طرح (برحسب کیلومتر)</label>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <input type="text" class="form-control" id="distance" name="distance" value="<?php echo e($plan->distance); ?>">
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if( $documents->isNotEmpty() ): ?>
                                        <div class="form repeater-default mt-6 row align-items-center">
                                        <div class="col-lg-10">
                                            <div data-repeater-list="observe_files">
                                                <div data-repeater-item>
                                                    <div class="row justify-content-between text-right">
                                                        <div class="col-md-4 col-sm-12 form-group">
                                                            <label for="document">نوع مدرک</label>
                                                            <select name="document" id="document" class="form-control" required>
                                                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($document->id); ?>"><?php echo e($document->title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        <div class="col-md-4 col-sm-12 form-group">
                                                            <label for="" class="form-label">بارگزاری فایل</label>
                                                            <input type="file" name="file" accept="image/*" capture="camera">
                                                        </div>

                                                        <div class="col-md-2 col-sm-12 form-group d-flex align-items-center pt-2">
                                                            <button class="btn btn-danger" data-repeater-delete type="button"> <i class="bx bx-x"></i>
                                                                حذف
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="col p-0">
                                                <button class="btn btn-primary d-flex" data-repeater-create type="button">
                                                    <i class="fas fa-plus"></i>
                                                    افزودن
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="text-center">
                                            <h3 class="text-success text-3xl mb-3"><strong>مدارک این طرح کامل می باشد</strong></h3>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <button class="btn btn-primary" type="submit">ذخیره کردن</button>
                        </form>

                        <div id="map"></div>
                        <div id="msg"></div>
                    </div>
                    <div class="tab-pane" id="tab_forms_widget_2" role="tabpanel">
                        <div class="text-right" style="display: grid; grid-template-columns: repeat(4, 1fr)">
                            <?php $__currentLoopData = $observes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h3 class="text-success"><strong><?php echo e($observe->observe_date); ?> : انجام شد</strong></h3>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab_forms_widget_3" role="tabpanel">
                        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px">
                            <?php $__currentLoopData = $planDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-center">
                                    <p><strong><?php echo e($document->title); ?></strong></p>
                                    <img src="<?php echo e(asset('/uploads/' . $document->image->url)); ?>" alt="">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('dashboard_extra_js'); ?>
    <script src="<?php echo e(asset('/assets/js/persian-date.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/persian-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/jquery.repeater.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/compressor.min.js')); ?>"></script>
    <script>
        // const Jimp = require('jimp');
        let form = document.querySelector('form');
        var formDataToUpload = new FormData(form);
        formDataToUpload.append('_token', '<?php echo e(csrf_token()); ?>');

        // document.querySelectorAll('[data-repeater-item] #document').forEach( item => {
        //
        // } )

        $(document).on('change', 'input[type=file], [data-repeater-item] #document', e => {
            if( e.target.tagName === 'INPUT' ){
                const file = e.target.files[0];

                if (!file) {
                    return;
                }

                // formDataToUpload.delete('file')

                new Compressor(file, {
                    quality: 0.9,
                    convertTypes: 'image/png',
                    convertSize: 150000,
                    success(result){
                        console.log(result)
                        refreshFormData(e.target, true, result);
                    },
                    error(err) {
                        console.log(err.message);
                    },
                });
            }
            else{
                refreshFormData(e.target, false);
            }
        });

        function getLocation() {
            Swal.fire({
                title: 'مجوز',
                text: 'لطفا دسترسی به موقعیت مکانی خود را به مرورگر بدهید و سپس ۵ ثانیه صبر کنید تا موقعیت شما دریافت شود',
                type: 'info',
                confirmButtonText: "بله"
            });
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                x.innerHTML = "این مرورگر نمی تواند موقعیت فعلی شما را پیدا کند";
            }
        }

        function showPosition(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            document.querySelector('#latitude').value = latitude;
            document.querySelector('#longitude').value = longitude;

            document.querySelector('#calcDistance').setAttribute('data-p1-lat', latitude);
            document.querySelector('#calcDistance').setAttribute('data-p1-lng', longitude);
        }

        document.querySelector('form').addEventListener('submit', e => {
            e.preventDefault();
            let formData = new FormData(document.querySelector('form'));
            formDataToUpload.append('observe_date', formData.get('observe_date'))
            formDataToUpload.append('latitude', formData.get('latitude'))
            formDataToUpload.append('longitude', formData.get('longitude'))

            Swal.fire({
                title: 'ذخیره',
                text: 'آیا از ثبت نظارت اطمینان دارد؟',
                icon: 'question',
                confirmButtonText: 'بله',
                showCancelButton: true,
                cancelButtonText: 'خیر',
                preConfirm: login => {
                    $.ajax({
                        url:"<?php echo e(route('observes.store', $plan->id)); ?>",
                        data: formDataToUpload,// Add as Data the Previously create formData
                        type:"POST",
                        contentType:false,
                        processData:false,
                        cache:false,
                        dataType:"json", // Change this according to your response from the server.
                        error:function(err){
                            throw new Error(err)
                        },
                        success:function(data){
                            return data;
                        },
                        complete:function(){
                            return true;
                        }
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then( result => {
                if( result.isConfirmed ){
                    Swal.fire({
                        title: 'بازدید با موفقیت ثبت شد',
                        icon: 'success',
                    });
                    window.location.href = '<?php echo e(route('plans.index')); ?>'
                }
            } );
        })

        // $(".persianDate").pDatepicker({
        //     format: 'YYYY/MM/DD'
        // });

        $('#persianDateBox').persianDatepicker({
            inline: true,
            altField: '.persianDate',
            altFormat: 'YYYY/MM/DD',
            toolbox:{
                calendarSwitch:{
                    enabled: false
                }
            },
            navigator:{
                scroll:{
                    enabled: false
                }
            },
            maxDate: new persianDate().add('month', 3).valueOf(),
            minDate: new persianDate().subtract('month', 3).valueOf(),
            timePicker: {
                enabled: false,
            }
        });

        $('.repeater-default').repeater({
            show: function () {
                $(this).slideDown();
            },
            hide: function (deleteElement) {
                Swal.fire({
                    title: 'حذف',
                    text: "از حذف کردن این فایل اطمینان دارید؟",
                    showDenyButton: true,
                    confirmButtonText: 'خیر',
                    denyButtonText: `بله`,
                    focusConfirm: true
                }).then( result => {
                    if( result.isDenied ){
                        $(this).slideUp(deleteElement);
                    }
                } );
            }
        });

        function refreshFormData(element, isCompressed = true, result = null){
            let doc = element.closest('.row').querySelector('#document');
            let documentName = doc.getAttribute('name').split('[')[0];
            let count = document.querySelectorAll('[data-repeater-item]').length - 1;

            if( isCompressed ){
                formDataToUpload.append(`${documentName}[${count}][compressed]`, result, result.name);
                formDataToUpload.append(`${documentName}[${count}][document]`, doc.value);
            }
            else{
                formDataToUpload.append(`${documentName}[${count}][document]`, doc.value);
            }
        }

        // function rad(x) {
        //     return x * Math.PI / 180;
        // }

        // function calculateDistance(elem){
        //     point1Lat = elem.getAttribute('data-p1-lat');
        //     point1Lng = elem.getAttribute('data-p1-lng');
        //     point2Lat = elem.getAttribute('data-p2-lat');
        //     point2Lng = elem.getAttribute('data-p2-lng');
        //
        //
        //     var R = 6378137; // Earth’s mean radius in meter
        //     var dLat = rad(point2Lat - point1Lat);
        //     var dLong = rad(point2Lng - point1Lng);
        //     var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        //         Math.cos(rad(point1Lat)) * Math.cos(rad(point2Lat)) *
        //         Math.sin(dLong / 2) * Math.sin(dLong / 2);
        //     var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        //     var d = R * c;
        // }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniyal_s/projects/observe8/resources/views/pages/observes/add.blade.php ENDPATH**/ ?>