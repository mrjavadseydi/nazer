<?php $__env->startSection('dashboard_page_title', 'لیست مدارک'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container-fluid text-right">
        <a href="<?php echo e(route('documents.create')); ?>" class="btn btn-primary btn-lg">افزودن مدرک جدید</a>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('documents', [])->html();
} elseif ($_instance->childHasBeenRendered('bN8UceZ')) {
    $componentId = $_instance->getRenderedChildComponentId('bN8UceZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('bN8UceZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bN8UceZ');
} else {
    $response = \Livewire\Livewire::mount('documents', []);
    $html = $response->html();
    $_instance->logRenderedChild('bN8UceZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('dashboard_extra_js'); ?>
    <script>
        document.querySelectorAll('.data-remove').forEach( item => {
            item.addEventListener('click', e => {
                e.preventDefault();

                Swal.fire({
                    title: 'حذف',
                    text: 'آیا از حذف کردن این مدرک اطمینان دارید؟',
                    icon: 'question',
                    confirmButtonText: 'بله',
                    showCancelButton: true,
                    cancelButtonText: 'خیر'
                }).then( result => {
                    if( result.isConfirmed ){
                        item.closest('div').querySelector('form').submit();
                    }
                } );
            });
        } )
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniyal_s/projects/observe8/resources/views/pages/documents/index.blade.php ENDPATH**/ ?>