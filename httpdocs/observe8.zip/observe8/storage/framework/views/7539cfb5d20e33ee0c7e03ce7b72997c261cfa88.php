<div>
    <a href="<?php echo e(route('observes.create', $id)); ?>" class="btn btn-sm btn-primary">
        ثبت نظارت
    </a>
</div>
<?php /**PATH /home/daniyal_s/projects/observe8/resources/views/livewire/plans-datatable.blade.php ENDPATH**/ ?>