<?php $__env->startSection('dashboard_page_title', 'لیست ادارات'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container-fluid text-right">
        <a href="<?php echo e(route('organizations.create')); ?>" class="btn btn-primary btn-lg">افزودن اداره جدید</a>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('organizations', [])->html();
} elseif ($_instance->childHasBeenRendered('Q7p6dIe')) {
    $componentId = $_instance->getRenderedChildComponentId('Q7p6dIe');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q7p6dIe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q7p6dIe');
} else {
    $response = \Livewire\Livewire::mount('organizations', []);
    $html = $response->html();
    $_instance->logRenderedChild('Q7p6dIe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('dashboard_extra_js'); ?>
    <script>
        document.querySelectorAll('.data-remove').forEach( item => {
            item.addEventListener('click', e => {
                e.preventDefault();

                Swal.fire({
                    title: 'حذف',
                    text: 'آیا از حذف کردن این مدرک اطمینان دارید؟',
                    icon: 'question',
                    confirmButtonText: 'بله',
                    showCancelButton: true,
                    cancelButtonText: 'خیر'
                }).then( result => {
                    if( result.isConfirmed ){
                        item.closest('div').querySelector('form').submit();
                    }
                } );
            });
        } )
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniyal_s/projects/observe8/resources/views/pages/organizations/index.blade.php ENDPATH**/ ?>