<?php $__env->startSection('dashboard_page_title', 'لیست طرح ها'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container-fluid">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('plans', [])->html();
} elseif ($_instance->childHasBeenRendered('dIxWouy')) {
    $componentId = $_instance->getRenderedChildComponentId('dIxWouy');
    $componentTag = $_instance->getRenderedChildComponentTagName('dIxWouy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dIxWouy');
} else {
    $response = \Livewire\Livewire::mount('plans', []);
    $html = $response->html();
    $_instance->logRenderedChild('dIxWouy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniyal_s/projects/observe8/resources/views/pages/plans/index.blade.php ENDPATH**/ ?>