<?php $__env->startSection('dashboard_page_title', 'لیست ناظران'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container-fluid text-right">
        <a href="<?php echo e(route('supervisors.create')); ?>" class="btn btn-primary btn-lg">افزودن ناظر جدید</a>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('supervisors', [])->html();
} elseif ($_instance->childHasBeenRendered('qGuaNJY')) {
    $componentId = $_instance->getRenderedChildComponentId('qGuaNJY');
    $componentTag = $_instance->getRenderedChildComponentTagName('qGuaNJY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qGuaNJY');
} else {
    $response = \Livewire\Livewire::mount('supervisors', []);
    $html = $response->html();
    $_instance->logRenderedChild('qGuaNJY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('dashboard_extra_js'); ?>
    <script>
        document.querySelectorAll('.data-remove').forEach( item => {
            item.addEventListener('click', e => {
                e.preventDefault();

                Swal.fire({
                    title: 'حذف',
                    text: 'آیا از حذف کردن این مدرک اطمینان دارید؟',
                    icon: 'question',
                    confirmButtonText: 'بله',
                    showCancelButton: true,
                    cancelButtonText: 'خیر'
                }).then( result => {
                    if( result.isConfirmed ){
                        item.closest('div').querySelector('form').submit();
                    }
                } );
            });
        } )
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniyal_s/projects/observe8/resources/views/pages/supervisors/index.blade.php ENDPATH**/ ?>