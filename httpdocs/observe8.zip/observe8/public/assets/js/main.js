// const { Pjax } = window['pjax-api'];
//
// new Pjax({
//     areas: [
//         '#kt_content',
//     ]
// });
